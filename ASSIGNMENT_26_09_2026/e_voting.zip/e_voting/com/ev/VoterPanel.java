package e_voting.com.ev;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class VoterPanel extends JPanel {
    private final User currentUser;

    private final JTextField regField  = new JTextField(20);
    private final JTextField nameField = new JTextField(24);
    private final JPasswordField pinField = new JPasswordField(20);
    private final JCheckBox activeCheck = new JCheckBox("Active", true);

    private final JButton saveBtn = new JButton("Save");
    private final JButton updateBtn = new JButton("Update");
    private final JButton deleteBtn = new JButton("Delete");
    private final JButton clearBtn = new JButton("Clear");
    private final JButton refreshBtn = new JButton("Refresh");

    private final DefaultTableModel tableModel = new DefaultTableModel(
        new Object[]{"ID","Reg No","Full Name","Active","Created"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(tableModel);

    private Long selectedId = null;

    public VoterPanel(User currentUser) {
        this.currentUser = currentUser;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        int y=0;
        gc.anchor=GridBagConstraints.EAST; gc.gridx=0; gc.gridy=y; form.add(new JLabel("Reg No:"), gc);
        gc.anchor=GridBagConstraints.WEST; gc.gridx=1; form.add(regField, gc); y++;
        gc.anchor=GridBagConstraints.EAST; gc.gridx=0; gc.gridy=y; form.add(new JLabel("Full Name:"), gc);
        gc.anchor=GridBagConstraints.WEST; gc.gridx=1; form.add(nameField, gc); y++;
        gc.anchor=GridBagConstraints.EAST; gc.gridx=0; gc.gridy=y; form.add(new JLabel("PIN (set/change):"), gc);
        gc.anchor=GridBagConstraints.WEST; gc.gridx=1; form.add(pinField, gc); y++;
        gc.anchor=GridBagConstraints.WEST; gc.gridx=1; gc.gridy=y; form.add(activeCheck, gc); y++;

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.add(saveBtn); buttons.add(updateBtn); buttons.add(deleteBtn); buttons.add(clearBtn); buttons.add(refreshBtn);
        gc.anchor=GridBagConstraints.WEST; gc.gridx=1; gc.gridy=y; form.add(buttons, gc);

        add(form, BorderLayout.NORTH);

        table.setRowHeight(22);
        add(new JScrollPane(table), BorderLayout.CENTER);

        saveBtn.addActionListener(e -> save());
        updateBtn.addActionListener(e -> update());
        deleteBtn.addActionListener(e -> deleteSelected());
        clearBtn.addActionListener(e -> clearForm());
        refreshBtn.addActionListener(e -> loadAll());
        table.getSelectionModel().addListSelectionListener(e -> onRowSelected());

        loadAll();
        clearForm();
    }

    private void save() {
        String reg = regField.getText().trim();
        String name = nameField.getText().trim();
        String pin = new String(pinField.getPassword()).trim();
        int active = activeCheck.isSelected()?1:0;

        if (reg.isEmpty() || name.isEmpty() || pin.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Reg No, Full Name, and PIN are required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String hash = PasswordUtil.hash(pin);
        String sql = "INSERT INTO voter(reg_no, full_name, pin_hash, active) VALUES(?,?,?,?)";
        try (Connection con = Database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reg);
            ps.setString(2, name);
            ps.setString(3, hash);
            ps.setInt(4, active);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Saved.");
            clearForm(); loadAll();
        } catch (SQLException ex) {
            showError(ex, "Reg No must be unique.");
        }
    }

    private void update() {
        if (selectedId == null) { JOptionPane.showMessageDialog(this, "Select a row first."); return; }
        String reg = regField.getText().trim();
        String name = nameField.getText().trim();
        String pin = new String(pinField.getPassword()).trim();
        int active = activeCheck.isSelected()?1:0;

        if (reg.isEmpty() || name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Reg No and Full Name are required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String sql = pin.isEmpty()
            ? "UPDATE voter SET reg_no=?, full_name=?, active=? WHERE voter_id=?"
            : "UPDATE voter SET reg_no=?, full_name=?, pin_hash=?, active=? WHERE voter_id=?";
        try (Connection con = Database.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            int i=1;
            ps.setString(i++, reg);
            ps.setString(i++, name);
            if (!pin.isEmpty()) { ps.setString(i++, PasswordUtil.hash(pin)); }
            ps.setInt(i++, active);
            ps.setLong(i, selectedId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Updated.");
            clearForm(); loadAll();
        } catch (SQLException ex) {
            showError(ex, "Reg No must be unique.");
        }
    }

    private void deleteSelected() {
        if (selectedId == null) { JOptionPane.showMessageDialog(this, "Select a row first."); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete voter? (blocked if ballots exist)", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM voter WHERE voter_id=?")) {
            ps.setLong(1, selectedId);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "Deleted.");
            clearForm(); loadAll();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Cannot delete (has ballots or referenced). " + ex.getMessage(), "Delete failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadAll() {
        tableModel.setRowCount(0);
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT voter_id, reg_no, full_name, active, created_at FROM voter ORDER BY voter_id DESC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getLong("voter_id"));
                row.add(rs.getString("reg_no"));
                row.add(rs.getString("full_name"));
                row.add(rs.getInt("active")==1 ? "Yes":"No");
                row.add(rs.getString("created_at"));
                tableModel.addRow(row);
            }
        } catch (SQLException ex) { showError(ex, null); }
    }

    private void onRowSelected() {
        if (table.getSelectedRow() < 0) return;
        int r = table.getSelectedRow();
        selectedId = (Long) tableModel.getValueAt(r, 0);
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT reg_no, full_name, active FROM voter WHERE voter_id=?")) {
            ps.setLong(1, selectedId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    regField.setText(rs.getString("reg_no"));
                    nameField.setText(rs.getString("full_name"));
                    activeCheck.setSelected(rs.getInt("active")==1);
                    pinField.setText(""); // never load hashes
                }
            }
        } catch (SQLException ex) { showError(ex, null); }
    }

    private void clearForm() {
        selectedId = null;
        regField.setText("");
        nameField.setText("");
        pinField.setText("");
        activeCheck.setSelected(true);
        table.clearSelection();
        regField.requestFocus();
    }

    private void showError(SQLException ex, String hint) {
        ex.printStackTrace();
        String m = ex.getMessage();
        if (hint != null && m != null && m.toLowerCase().contains("unique")) {
            JOptionPane.showMessageDialog(this, hint, "Duplicate", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "DB error: " + m, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
