package e_voting.com.ev;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.sql.*;
import java.util.ArrayList;

public class VoterKioskFrame extends JFrame {
    private final JComboBox<ComboItem> electionCombo = new JComboBox<>();
    private final JButton refreshElectionsBtn = new JButton("Refresh Elections");

    private final JTextField regField = new JTextField(16);
    private final JPasswordField pinField = new JPasswordField(16);

    private final JPanel candidatesPanel = new JPanel(new GridLayout(0,1,4,4));
    private final ButtonGroup candGroup = new ButtonGroup();
    private final JButton voteBtn = new JButton("Cast Vote");

    private final java.util.List<RadioHolder> radioRefs = new ArrayList<>();

    public VoterKioskFrame() {
        super("E-Voting Kiosk");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(560, 560);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8,8));
        ((JComponent)getContentPane()).setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // top section
        JPanel top = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        int y=0;

        gc.gridx=0; gc.gridy=y; gc.anchor=GridBagConstraints.EAST; top.add(new JLabel("Election:"), gc);
        gc.gridx=1; gc.anchor=GridBagConstraints.WEST; top.add(electionCombo, gc);
        gc.gridx=2; top.add(refreshElectionsBtn, gc); y++;

        gc.gridx=0; gc.gridy=y; gc.anchor=GridBagConstraints.EAST; top.add(new JLabel("Voter Reg No:"), gc);
        gc.gridx=1; gc.anchor=GridBagConstraints.WEST; top.add(regField, gc); y++;

        gc.gridx=0; gc.gridy=y; gc.anchor=GridBagConstraints.EAST; top.add(new JLabel("PIN:"), gc);
        gc.gridx=1; gc.anchor=GridBagConstraints.WEST; top.add(pinField, gc); y++;

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
        btns.add(voteBtn);
        gc.gridx=1; gc.gridy=y; gc.anchor=GridBagConstraints.WEST; top.add(btns, gc);

        add(top, BorderLayout.NORTH);

        JScrollPane scroll = new JScrollPane(candidatesPanel);
        scroll.setBorder(BorderFactory.createTitledBorder("Candidates"));
        add(scroll, BorderLayout.CENTER);

        // events
        refreshElectionsBtn.addActionListener(e -> loadOpenElections());
        voteBtn.addActionListener(e -> castVote());
        electionCombo.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) loadCandidatesForSelected();
        });

        // first load
        loadOpenElections();
    }

    private void loadOpenElections() {
        electionCombo.removeAllItems();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                // Only OPEN elections whose time window includes NOW()
                "SELECT election_id, name FROM election " +
                "WHERE status='OPEN' AND NOW() BETWEEN start_at AND end_at " +
                "ORDER BY election_id DESC");
             ResultSet rs = ps.executeQuery()) {
            int count = 0;
            while (rs.next()) {
                electionCombo.addItem(new ComboItem(rs.getLong("election_id"), rs.getString("name")));
                count++;
            }
            if (count == 0) {
                info("No OPEN elections are active right now.\n" +
                     "Open one in the Elections tab (status=OPEN and Start/End around now).");
                clearCandidates();
            } else {
                // trigger loading candidates for the first election
                loadCandidatesForSelected();
            }
        } catch (SQLException ex) {
            error("Failed to load elections: " + ex.getMessage());
        }
    }

    private void clearCandidates() {
        candidatesPanel.removeAll();
        candGroup.clearSelection();
        radioRefs.clear();
        candidatesPanel.revalidate();
        candidatesPanel.repaint();
    }

    private void loadCandidatesForSelected() {
        clearCandidates();
        ComboItem it = (ComboItem) electionCombo.getSelectedItem();
        if (it == null) return;

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                "SELECT candidate_id, full_name, COALESCE(party,'') AS party " +
                "FROM candidate WHERE election_id=? ORDER BY candidate_id ASC")) {
            ps.setLong(1, it.id);
            try (ResultSet rs = ps.executeQuery()) {
                int idx = 1, rows = 0;
                while (rs.next()) {
                    long cid = rs.getLong("candidate_id");
                    String label = (idx++) + ". " + rs.getString("full_name");
                    String party = rs.getString("party");
                    if (party != null && !party.isBlank()) label += " (" + party + ")";
                    JRadioButton rb = new JRadioButton(label);
                    candGroup.add(rb);
                    candidatesPanel.add(rb);
                    radioRefs.add(new RadioHolder(rb, cid));
                    rows++;
                }
                if (rows == 0) {
                    info("This election has no candidates yet.");
                }
            }
        } catch (SQLException ex) {
            error("Failed to load candidates: " + ex.getMessage());
        }

        candidatesPanel.revalidate();
        candidatesPanel.repaint();
    }

    private void castVote() {
        ComboItem it = (ComboItem) electionCombo.getSelectedItem();
        if (it == null) { info("Select an active election first."); return; }

        String reg = regField.getText().trim();
        String pin = new String(pinField.getPassword()).trim();
        if (reg.isEmpty() || pin.isEmpty()) { info("Enter Reg No and PIN."); return; }

        Long chosenCandidateId = null;
        for (RadioHolder h : radioRefs) if (h.rb.isSelected()) { chosenCandidateId = h.candidateId; break; }
        if (chosenCandidateId == null) { info("Pick a candidate."); return; }

        try (Connection con = Database.getConnection()) {
            // verify voter
            long voterId; String pinHash; int active;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT voter_id, pin_hash, active FROM voter WHERE reg_no=? LIMIT 1")) {
                ps.setString(1, reg);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) { error("No such voter."); return; }
                    voterId = rs.getLong("voter_id");
                    pinHash = rs.getString("pin_hash");
                    active = rs.getInt("active");
                }
            }
            if (active != 1) { error("Voter is inactive."); return; }
            if (!PasswordUtil.matches(pin, pinHash)) { error("Invalid PIN."); return; }

            // one vote per voter per election
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT 1 FROM ballot WHERE election_id=? AND voter_id=? LIMIT 1")) {
                ps.setLong(1, it.id);
                ps.setLong(2, voterId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) { error("This voter has already voted in this election."); return; }
                }
            }

            // cast ballot
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO ballot(election_id, voter_id, candidate_id) VALUES(?,?,?)")) {
                ps.setLong(1, it.id);
                ps.setLong(2, voterId);
                ps.setLong(3, chosenCandidateId);
                ps.executeUpdate();
            }

            JOptionPane.showMessageDialog(this, "Vote cast successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            regField.setText(""); pinField.setText(""); candGroup.clearSelection();

        } catch (SQLException ex) {
            error("Failed to cast vote: " + ex.getMessage());
        }
    }

    private void info(String m)  { JOptionPane.showMessageDialog(this, m, "Info", JOptionPane.INFORMATION_MESSAGE); }
    private void error(String m) { JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE); }

    // small holders
    private static class ComboItem {
        final Long id; final String label;
        ComboItem(Long id, String label) { this.id=id; this.label=label; }
        @Override public String toString() { return label; }
    }
    private static class RadioHolder {
        final JRadioButton rb; final long candidateId;
        RadioHolder(JRadioButton rb, long id) { this.rb=rb; this.candidateId=id; }
    }
}
