package e_voting.com.ev;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.sql.*;

public class ResultsPanel extends JPanel {
    private final JComboBox<ComboItem> electionCombo = new JComboBox<>();
    private final JButton reloadBtn = new JButton("Reload Elections");
    private final JButton refreshBtn = new JButton("Refresh Tally");

    private final JLabel statusLbl = new JLabel("Status: -");
    private final JLabel windowLbl = new JLabel("Window: -");
    private final JLabel totalLbl  = new JLabel("Total ballots: 0");

    private final DefaultTableModel model = new DefaultTableModel(
        new Object[]{"#","Candidate","Party","Votes"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);

    public ResultsPanel(User currentUser) {
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // top bar
        JPanel top = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(4,4,4,4);
        gc.gridx=0; gc.gridy=0; gc.anchor=GridBagConstraints.EAST; top.add(new JLabel("Election:"), gc);
        gc.gridx=1; gc.anchor=GridBagConstraints.WEST; top.add(electionCombo, gc);
        gc.gridx=2; top.add(reloadBtn, gc);
        gc.gridx=3; top.add(refreshBtn, gc);
        add(top, BorderLayout.NORTH);

        // info bar
        JPanel info = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        info.add(statusLbl); info.add(windowLbl); info.add(totalLbl);
        add(info, BorderLayout.SOUTH);

        // table
        table.setRowHeight(24);
        table.setAutoCreateRowSorter(true);
        setPrefWidth(0, 50); setPrefWidth(1, 240); setPrefWidth(2, 160); setPrefWidth(3, 100);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // events
        reloadBtn.addActionListener(e -> loadElections());
        refreshBtn.addActionListener(e -> loadTally());
        electionCombo.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) loadTally();
        });

        // first load
        loadElections();
    }

    private void setPrefWidth(int col, int w) {
        TableColumn c = table.getColumnModel().getColumn(col);
        c.setPreferredWidth(w);
        if (col == 0) c.setMaxWidth(60);
    }

    private void loadElections() {
        electionCombo.removeAllItems();
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                 "SELECT election_id, name, status, start_at, end_at " +
                 "FROM election ORDER BY election_id DESC");
             ResultSet rs = ps.executeQuery()) {
            int count = 0;
            while (rs.next()) {
                electionCombo.addItem(new ComboItem(
                        rs.getLong("election_id"),
                        rs.getString("name"),
                        rs.getString("status"),
                        rs.getString("start_at"),
                        rs.getString("end_at")
                ));
                count++;
            }
            if (count == 0) {
                model.setRowCount(0);
                statusLbl.setText("Status: -");
                windowLbl.setText("Window: -");
                totalLbl.setText("Total ballots: 0");
                JOptionPane.showMessageDialog(this, "No elections found. Create one in Elections tab.",
                        "Info", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // trigger tally for first item
                loadTally();
            }
        } catch (SQLException ex) {
            showErr("Failed to load elections: " + ex.getMessage());
        }
    }

    private void loadTally() {
        model.setRowCount(0);
        ComboItem it = (ComboItem) electionCombo.getSelectedItem();
        if (it == null) return;

        statusLbl.setText("Status: " + it.status);
        windowLbl.setText("Window: " + it.startAt + " → " + it.endAt);
        totalLbl.setText("Total ballots: …");

        // total ballots
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT COUNT(*) FROM ballot WHERE election_id=?")) {
            ps.setLong(1, it.id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) totalLbl.setText("Total ballots: " + rs.getInt(1));
            }
        } catch (SQLException ex) {
            totalLbl.setText("Total ballots: ?");
        }

        // tally by candidate
        final String sql = """
            SELECT c.candidate_id, c.full_name, c.party, COUNT(b.ballot_id) AS votes
            FROM candidate c
            LEFT JOIN ballot b ON b.candidate_id = c.candidate_id
            WHERE c.election_id = ?
            GROUP BY c.candidate_id, c.full_name, c.party
            ORDER BY votes DESC, c.full_name ASC
        """;

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, it.id);
            try (ResultSet rs = ps.executeQuery()) {
                int rank = 1; boolean any = false;
                while (rs.next()) {
                    any = true;
                    model.addRow(new Object[]{
                        rank++,
                        rs.getString("full_name"),
                        rs.getString("party"),
                        rs.getInt("votes")
                    });
                }
                if (!any) {
                    JOptionPane.showMessageDialog(this,
                        "No candidates for this election (or all have 0 votes).",
                        "Info", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            showErr("Failed to load tally: " + ex.getMessage());
        }
    }

    private void showErr(String m) {
        JOptionPane.showMessageDialog(this, m, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static class ComboItem {
        final Long id; final String label; final String status; final String startAt; final String endAt;
        ComboItem(Long id, String name, String status, String startAt, String endAt) {
            this.id = id; this.label = name; this.status = status; this.startAt = startAt; this.endAt = endAt;
        }
        @Override public String toString() { return label; }
    }
}
