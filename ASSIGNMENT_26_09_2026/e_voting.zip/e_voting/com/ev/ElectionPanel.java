package e_voting.com.ev;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.HierarchyEvent;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;

public class ElectionPanel extends JPanel {
    private static final DateTimeFormatter DT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private final User currentUser;

    // election form
    private final JTextField nameField  = new JTextField(24);
    private final JTextField startField = new JTextField(16); // yyyy-MM-dd HH:mm
    private final JTextField endField   = new JTextField(16);
    private final JComboBox<String> statusCombo = new JComboBox<>(new String[]{"DRAFT","OPEN","CLOSED"});

    private final JButton saveBtn    = new JButton("Save");
    private final JButton updateBtn  = new JButton("Update");
    private final JButton deleteBtn  = new JButton("Delete");
    private final JButton clearBtn   = new JButton("Clear");
    private final JButton refreshBtn = new JButton("Refresh");

    private final DefaultTableModel electionModel = new DefaultTableModel(
        new Object[]{"ID","Name","Start","End","Status","Created"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable electionTable = new JTable(electionModel);
    private Long selectedElectionId = null;

    // candidate sub-panel
    private final JTextField candNameField = new JTextField(20);
    private final JTextField partyField    = new JTextField(16);
    private final JButton candAddBtn = new JButton("Add Candidate");
    private final JButton candDelBtn = new JButton("Delete Candidate");
    private final DefaultTableModel candModel = new DefaultTableModel(
        new Object[]{"ID","Full Name","Party","Created"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable candTable = new JTable(candModel);

    public ElectionPanel(User currentUser) {
        this.currentUser = currentUser;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // ----- TOP: form card (with padding) -----
        add(makeFormCard(), BorderLayout.NORTH);

        // ----- CENTER: split pane with election table (top) and candidate area (bottom) -----
        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                wrapInScroll(electionTable, "Elections"),
                makeCandidateArea());
        split.setContinuousLayout(true);
        split.setResizeWeight(0.60); // 60% to elections, 40% to candidates
        add(split, BorderLayout.CENTER);

        // tune tables visually
        styleTables();

        // actions
        saveBtn.addActionListener(e -> saveElection());
        updateBtn.addActionListener(e -> updateElection());
        deleteBtn.addActionListener(e -> deleteElection());
        clearBtn.addActionListener(e -> clearElectionForm());
        refreshBtn.addActionListener(e -> { loadElections(); loadCandidates(); });

        electionTable.getSelectionModel().addListSelectionListener(e -> onElectionRowSelected());
        candAddBtn.addActionListener(e -> addCandidate());
        candDelBtn.addActionListener(e -> deleteCandidate());
        candTable.getSelectionModel().addListSelectionListener(e -> onCandidateRowSelected());

        // first load
        loadElections();
        clearElectionForm();

        // set a reasonable divider after first layout
        addHierarchyListener(ev -> {
            if ((ev.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && isShowing()) {
                split.setDividerLocation(0.55);
                removeHierarchyListener(this.getHierarchyListeners()[0]); // run once
            }
        });
    }

    private void onCandidateRowSelected() {
        int rView = candTable.getSelectedRow();
        if (rView < 0) return; // nothing selected
        int r = candTable.convertRowIndexToModel(rView); // handle sorting
        candNameField.setText((String) candModel.getValueAt(r, 1));
        partyField.setText((String) candModel.getValueAt(r, 2));
    }

    private JComponent makeFormCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220,220,220)),
                BorderFactory.createEmptyBorder(8,8,8,8)));

        GridBagConstraints l = new GridBagConstraints();
        GridBagConstraints f = new GridBagConstraints();

        l.insets = new Insets(4,4,4,8);
        l.anchor = GridBagConstraints.EAST;
        l.gridx = 0;

        f.insets = new Insets(4,4,4,4);
        f.anchor = GridBagConstraints.WEST;
        f.gridx = 1;
        f.weightx = 1.0;
        f.fill = GridBagConstraints.HORIZONTAL;

        int y = 0;
        l.gridy = y; card.add(new JLabel("Name:"), l);
        f.gridy = y++; card.add(nameField, f);

        l.gridy = y; card.add(new JLabel("Start (yyyy-MM-dd HH:mm):"), l);
        f.gridy = y++; card.add(startField, f);

        l.gridy = y; card.add(new JLabel("End (yyyy-MM-dd HH:mm):"), l);
        f.gridy = y++; card.add(endField, f);

        l.gridy = y; card.add(new JLabel("Status:"), l);
        f.gridy = y++; card.add(statusCombo, f);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        btns.add(saveBtn); btns.add(updateBtn); btns.add(deleteBtn); btns.add(clearBtn); btns.add(refreshBtn);

        GridBagConstraints b = new GridBagConstraints();
        b.gridx = 0; b.gridy = y; b.gridwidth = 2;
        b.insets = new Insets(6,4,2,4);
        b.anchor = GridBagConstraints.WEST;
        card.add(btns, b);

        return card;
    }

    private JScrollPane wrapInScroll(JTable table, String title) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder(title));
        return sp;
    }

    private JComponent makeCandidateArea() {
        JPanel area = new JPanel(new BorderLayout(6,6));
        area.setBorder(BorderFactory.createTitledBorder("Candidates (of selected election)"));

        JPanel candForm = new JPanel(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(4,4,4,4);

        int y=0;
        c.anchor=GridBagConstraints.EAST; c.gridx=0; c.gridy=y; candForm.add(new JLabel("Candidate:"), c);
        c.anchor=GridBagConstraints.WEST; c.gridx=1; c.gridy=y; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL; candForm.add(candNameField, c); y++;
        c.weightx=0; c.fill=GridBagConstraints.NONE;

        c.anchor=GridBagConstraints.EAST; c.gridx=0; c.gridy=y; candForm.add(new JLabel("Party:"), c);
        c.anchor=GridBagConstraints.WEST; c.gridx=1; c.gridy=y; c.weightx=1; c.fill=GridBagConstraints.HORIZONTAL; candForm.add(partyField, c); y++;

        JPanel cb = new JPanel(new FlowLayout(FlowLayout.LEFT,8,0));
        cb.add(candAddBtn); cb.add(candDelBtn);

        GridBagConstraints cbtn = new GridBagConstraints();
        cbtn.gridx=0; cbtn.gridy=y; cbtn.gridwidth=2; cbtn.anchor=GridBagConstraints.WEST; cbtn.insets=new Insets(2,4,4,4);
        candForm.add(cb, cbtn);

        area.add(candForm, BorderLayout.NORTH);
        area.add(new JScrollPane(candTable), BorderLayout.CENTER);
        return area;
    }

    private void styleTables() {
        electionTable.setRowHeight(24);
        electionTable.setAutoCreateRowSorter(true);
        electionTable.setFillsViewportHeight(true);
        electionTable.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        setPrefWidth(electionTable, 0, 60);   // ID
        setPrefWidth(electionTable, 1, 240);  // Name
        setPrefWidth(electionTable, 2, 150);  // Start
        setPrefWidth(electionTable, 3, 150);  // End
        setPrefWidth(electionTable, 4, 90);   // Status
        setPrefWidth(electionTable, 5, 140);  // Created

        candTable.setRowHeight(24);
        candTable.setAutoCreateRowSorter(true);
        candTable.setFillsViewportHeight(true);
        candTable.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        setPrefWidth(candTable, 0, 60);   // ID
        setPrefWidth(candTable, 1, 220);  // Full Name
        setPrefWidth(candTable, 2, 140);  // Party
        setPrefWidth(candTable, 3, 140);  // Created
    }

    private void setPrefWidth(JTable t, int col, int w) {
        TableColumn c = t.getColumnModel().getColumn(col);
        c.setPreferredWidth(w);
        if (col == 0) { c.setMaxWidth(80); } // keep ID slim
    }

    // ==== Elections CRUD ====
    private void saveElection() {
        String name  = nameField.getText().trim();
        String start = startField.getText().trim();
        String end   = endField.getText().trim();
        String status= (String) statusCombo.getSelectedItem();

        if (name.isEmpty() || start.isEmpty() || end.isEmpty()) { info("Name, Start, End required."); return; }
        if (!validDT(start) || !validDT(end)) { info("Use 'yyyy-MM-dd HH:mm'"); return; }

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO election(name,start_at,end_at,status) VALUES(?,?,?,?)")) {
            ps.setString(1, name); ps.setString(2, start); ps.setString(3, end); ps.setString(4, status);
            ps.executeUpdate();
            info("Saved.");
            clearElectionForm(); loadElections();
        } catch (SQLException ex) { showError(ex, "Election name must be unique."); }
    }

    private void updateElection() {
        if (selectedElectionId == null) { info("Select an election first."); return; }
        String name  = nameField.getText().trim();
        String start = startField.getText().trim();
        String end   = endField.getText().trim();
        String status= (String) statusCombo.getSelectedItem();

        if (name.isEmpty() || start.isEmpty() || end.isEmpty()) { info("Name, Start, End required."); return; }
        if (!validDT(start) || !validDT(end)) { info("Use 'yyyy-MM-dd HH:mm'"); return; }

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE election SET name=?, start_at=?, end_at=?, status=? WHERE election_id=?")) {
            ps.setString(1, name); ps.setString(2, start); ps.setString(3, end); ps.setString(4, status);
            ps.setLong(5, selectedElectionId);
            ps.executeUpdate();
            info("Updated.");
            clearElectionForm(); loadElections(); loadCandidates();
        } catch (SQLException ex) { showError(ex, "Name must be unique."); }
    }

    private void deleteElection() {
        if (selectedElectionId == null) { info("Select an election first."); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete election (+ its candidates & ballots)?", "Confirm",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM election WHERE election_id=?")) {
            ps.setLong(1, selectedElectionId);
            ps.executeUpdate();
            info("Deleted.");
            clearElectionForm(); loadElections(); candModel.setRowCount(0);
        } catch (SQLException ex) { showError(ex, null); }
    }

    private void loadElections() {
        electionModel.setRowCount(0);
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT election_id,name,start_at,end_at,status,created_at FROM election ORDER BY election_id DESC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getLong("election_id"));
                row.add(rs.getString("name"));
                row.add(rs.getString("start_at"));
                row.add(rs.getString("end_at"));
                row.add(rs.getString("status"));
                row.add(rs.getString("created_at"));
                electionModel.addRow(row);
            }
        } catch (SQLException ex) { showError(ex, null); }
    }

    private void onElectionRowSelected() {
        if (electionTable.getSelectedRow() < 0) return;
        int rView = electionTable.getSelectedRow();
        int r = electionTable.convertRowIndexToModel(rView);

        selectedElectionId = (Long) electionModel.getValueAt(r, 0);
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT name,start_at,end_at,status FROM election WHERE election_id=?")) {
            ps.setLong(1, selectedElectionId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    nameField.setText(rs.getString("name"));
                    startField.setText(rs.getString("start_at"));
                    endField.setText(rs.getString("end_at"));
                    statusCombo.setSelectedItem(rs.getString("status"));
                }
            }
        } catch (SQLException ex) { showError(ex, null); }
        loadCandidates();
    }

    private void clearElectionForm() {
        selectedElectionId = null;
        nameField.setText("");
        startField.setText(LocalDateTime.now().format(DT));
        endField.setText(LocalDateTime.now().plusHours(2).format(DT));
        statusCombo.setSelectedItem("DRAFT");
        electionTable.clearSelection();
        candModel.setRowCount(0);
        candNameField.setText(""); partyField.setText("");
        nameField.requestFocus();
    }

    private boolean validDT(String s) {
        try { LocalDateTime.parse(s, DT); return true; } catch (Exception e) { return false; }
    }

    // ==== Candidate CRUD (for selected election) ====
    private void loadCandidates() {
        candModel.setRowCount(0);
        if (selectedElectionId == null) return;
        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT candidate_id, full_name, party, created_at FROM candidate WHERE election_id=? ORDER BY candidate_id DESC")) {
            ps.setLong(1, selectedElectionId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Vector<Object> row = new Vector<>();
                    row.add(rs.getLong("candidate_id"));
                    row.add(rs.getString("full_name"));
                    row.add(rs.getString("party"));
                    row.add(rs.getString("created_at"));
                    candModel.addRow(row);
                }
            }
        } catch (SQLException ex) { showError(ex, null); }
    }

    private void addCandidate() {
        if (selectedElectionId == null) { info("Select an election first."); return; }
        String nm = candNameField.getText().trim();
        String party = partyField.getText().trim();
        if (nm.isEmpty()) { info("Candidate name required."); return; }

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement(
                     "INSERT INTO candidate(election_id, full_name, party) VALUES(?,?,?)")) {
            ps.setLong(1, selectedElectionId);
            ps.setString(2, nm);
            ps.setString(3, party.isEmpty()?null:party);
            ps.executeUpdate();
            info("Candidate added.");
            candNameField.setText(""); partyField.setText("");
            loadCandidates();
        } catch (SQLException ex) {
            String m = ex.getMessage();
            if (m!=null && m.toLowerCase().contains("unique")) {
                info("Candidate already exists in this election.");
            } else showError(ex, null);
        }
    }

    private void deleteCandidate() {
        if (candTable.getSelectedRow() < 0) { info("Select a candidate row."); return; }
        int rView = candTable.getSelectedRow();
        int r = candTable.convertRowIndexToModel(rView);
        Long candId = (Long) candModel.getValueAt(r, 0);

        if (JOptionPane.showConfirmDialog(this, "Delete candidate? (blocked if ballots exist)",
                "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;

        try (Connection con = Database.getConnection();
             PreparedStatement ps = con.prepareStatement("DELETE FROM candidate WHERE candidate_id=?")) {
            ps.setLong(1, candId);
            ps.executeUpdate();
            info("Deleted.");
            loadCandidates();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Cannot delete (maybe ballots exist). " + ex.getMessage(),
                    "Delete failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ==== helpers ====
    private void info(String m) {
        JOptionPane.showMessageDialog(this, m, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
    private void showError(SQLException ex, String hint) {
        ex.printStackTrace();
        String m = ex.getMessage();
        if (hint != null && m != null && m.toLowerCase().contains("unique")) {
            JOptionPane.showMessageDialog(this, hint, "Duplicate", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "DB error: " + m, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
