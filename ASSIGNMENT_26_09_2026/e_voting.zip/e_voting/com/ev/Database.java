package e_voting.com.ev
;

import java.sql.*;

public class Database {
    // adjust to your server creds
    private static final String URL  = "jdbc:mysql://localhost:3306/e_vote_db";
    private static final String USER = "root";     
    private static final String PASS = "Hh@0790861884"; 

    public static Connection getConnection() throws SQLException {
        try { Class.forName("com.mysql.cj.jdbc.Driver"); }
        catch (ClassNotFoundException e) { throw new SQLException("MySQL driver missing", e); }
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static void init() {
        // With MySQL we created tables via SQL script.
        // Here we only ensure an admin exists.
        try (Connection con = getConnection()) {
            if (!adminExists(con)) {
                String email = "admin@evote.local";
                String pass  = "123456"; // change after first login
                String hash  = PasswordUtil.hash(pass);
                try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO user_account(full_name,email,password_hash,role,active) VALUES(?,?,?,?,1)")) {
                    ps.setString(1, "System Administrator");
                    ps.setString(2, email);
                    ps.setString(3, hash);
                    ps.setString(4, "ADMIN");
                    ps.executeUpdate();
                    System.out.println("[BOOTSTRAP] Admin: " + email + " / " + pass);
                }
            } else {
                System.out.println("[BOOTSTRAP] Admin already exists.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.err.println("DB init failed: " + e.getMessage());
        }
    }

    private static boolean adminExists(Connection con) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT 1 FROM user_account WHERE role='ADMIN' AND active=1 LIMIT 1");
             ResultSet rs = ps.executeQuery()) {
            return rs.next();
        }
    }
}
