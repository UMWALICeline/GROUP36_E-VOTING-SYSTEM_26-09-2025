package e_voting.com.ev
;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.sql.*;

public class EVotingDashboardFrame extends JFrame {
    private final User currentUser;
    private final JTabbedPane tabs = new JTabbedPane();

    // summary widgets
    private final JLabel votersLbl     = new JLabel("Voters: 0");
    private final JLabel candLbl       = new JLabel("Candidates: 0");
    private final JLabel openElecLbl   = new JLabel("Open Elections: 0");
    private final JLabel ballotsLbl    = new JLabel("Ballots: 0");

    // auto refresh every 10s
    private final javax.swing.Timer summaryTimer = new javax.swing.Timer(10_000, e -> refreshSummary());

    public EVotingDashboardFrame(User user) {
        super("E-Voting Admin Dashboard");
        this.currentUser = user;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 640);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        add(makeTopBar(), BorderLayout.NORTH);
        add(makeTabs(),   BorderLayout.CENTER);
        add(makeSummaryBar(), BorderLayout.SOUTH);
        setJMenuBar(makeMenuBar());

        // start summary refresh
        refreshSummary();
        summaryTimer.start();
    }

    private JMenuBar makeMenuBar() {
        JMenuBar mb = new JMenuBar();

        JMenu file = new JMenu("File");
        file.setMnemonic(KeyEvent.VK_F);
        JMenuItem kiosk = new JMenuItem("Open Voter Kiosk");
        kiosk.setMnemonic(KeyEvent.VK_K);
        kiosk.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        kiosk.addActionListener(e -> openKiosk());
        JMenuItem exit = new JMenuItem("Exit");
        exit.setMnemonic(KeyEvent.VK_X);
        exit.addActionListener(e -> dispose());
        file.add(kiosk); file.addSeparator(); file.add(exit);

        JMenu view = new JMenu("View");
        view.setMnemonic(KeyEvent.VK_V);
        JMenuItem refresh = new JMenuItem("Refresh Summary");
        refresh.setMnemonic(KeyEvent.VK_R);
        refresh.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
        refresh.addActionListener(e -> refreshSummary());
        view.add(refresh);

        JMenu help = new JMenu("Help");
        help.setMnemonic(KeyEvent.VK_H);
        JMenuItem about = new JMenuItem("About…");
        about.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "E-Voting Admin Dashboard (demo)\nSwing + SQLite\nNot for production elections.",
                "About", JOptionPane.INFORMATION_MESSAGE));
        help.add(about);

        mb.add(file); mb.add(view); mb.add(help);
        return mb;
    }

    private JComponent makeTopBar() {
        JPanel top = new JPanel(new BorderLayout());
        top.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        JLabel who = new JLabel("Logged in: " + currentUser.getFullName() + " [" + currentUser.getRole() + "]");
        top.add(who, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        JButton kioskBtn = new JButton("Open Voter Kiosk");
        kioskBtn.addActionListener(e -> openKiosk());
        JButton quitBtn = new JButton("Quit");
        quitBtn.addActionListener(e -> dispose());
        right.add(kioskBtn); right.add(quitBtn);
        top.add(right, BorderLayout.EAST);

        return top;
    }

    private JComponent makeSummaryBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 8));
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220,220,220)));
        votersLbl.setFont(votersLbl.getFont().deriveFont(Font.BOLD));
        candLbl.setFont(candLbl.getFont().deriveFont(Font.BOLD));
        openElecLbl.setFont(openElecLbl.getFont().deriveFont(Font.BOLD));
        ballotsLbl.setFont(ballotsLbl.getFont().deriveFont(Font.BOLD));
        bar.add(votersLbl); bar.add(candLbl); bar.add(openElecLbl); bar.add(ballotsLbl);
        return bar;
    }

    private JComponent makeTabs() {
        // plug in your existing panels (already provided earlier)
        tabs.addTab("Voters",    new VoterPanel(currentUser));
        tabs.addTab("Elections", new ElectionPanel(currentUser));
        tabs.addTab("Results",   new ResultsPanel(currentUser));

        // optional: welcome tab
        tabs.insertTab("Home", null, makeHomePanel(), "Overview", 0);
        tabs.setSelectedIndex(0);

        // refresh summary when switching tabs
        tabs.addChangeListener(e -> refreshSummary());
        return tabs;
    }

    private JPanel makeHomePanel() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(24,24,24,24));

        JTextArea ta = new JTextArea(
            "Welcome to the E-Voting Admin Dashboard.\n\n" +
            "Quick steps:\n" +
            "1) Create an election and add candidates (Elections tab)\n" +
            "2) Register voters (Voters tab)\n" +
            "3) Set election status to OPEN (within Start/End time)\n" +
            "4) Open Voter Kiosk → voters log in with RegNo + PIN and cast a vote\n" +
            "5) View live tally in Results tab\n\n"
        );
        ta.setEditable(false);
        ta.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        p.add(ta, BorderLayout.CENTER);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        JButton openKiosk = new JButton("Open Voter Kiosk");
        openKiosk.addActionListener(e -> openKiosk());
        JButton toElections = new JButton("Go to Elections");
        toElections.addActionListener(e -> tabs.setSelectedIndex(tabs.indexOfTab("Elections")));
        JButton toVoters = new JButton("Go to Voters");
        toVoters.addActionListener(e -> tabs.setSelectedIndex(tabs.indexOfTab("Voters")));
        btns.add(openKiosk); btns.add(toElections); btns.add(toVoters);
        p.add(btns, BorderLayout.SOUTH);

        return p;
    }

    private void openKiosk() {
        new VoterKioskFrame().setVisible(true);
    }

    private void refreshSummary() {
        // Counts: voters (total & active), candidates, open elections (time window + status), ballots
        try (Connection con = Database.getConnection()) {
            // voters
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c, SUM(CASE WHEN active=1 THEN 1 ELSE 0 END) AS a FROM voter");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) votersLbl.setText("Voters: " + rs.getInt("a") + " active / " + rs.getInt("c") + " total");
            }
            // candidates
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c FROM candidate");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) candLbl.setText("Candidates: " + rs.getInt("c"));
            }
            // open elections right now
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COUNT(*) AS c FROM election WHERE status='OPEN'  AND start_at<=NOW() AND end_at>=NOW()")) {
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) openElecLbl.setText("Open Elections: " + rs.getInt("c"));
                }
            }
            // ballots
            try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) AS c FROM ballot");
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) ballotsLbl.setText("Ballots: " + rs.getInt("c"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            ballotsLbl.setText("Ballots: ?");
        }
    }
}
