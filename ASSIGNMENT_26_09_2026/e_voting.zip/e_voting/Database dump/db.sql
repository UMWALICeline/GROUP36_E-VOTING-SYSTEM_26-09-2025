CREATE DATABASE IF NOT EXISTS evoting CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE evoting;

CREATE TABLE IF NOT EXISTS user_account (
  user_id       INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(200) NOT NULL,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('ADMIN','CLERK','JUDGE','LAWYER','READONLY') NOT NULL,
  active        TINYINT(1) NOT NULL DEFAULT 1,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS voter (
  voter_id   INT AUTO_INCREMENT PRIMARY KEY,
  reg_no     VARCHAR(64) NOT NULL UNIQUE,
  full_name  VARCHAR(200) NOT NULL,
  pin_hash   VARCHAR(255) NOT NULL,
  active     TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS election (
  election_id INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(200) NOT NULL UNIQUE,
  start_at    DATETIME NOT NULL,
  end_at      DATETIME NOT NULL,
  status      ENUM('DRAFT','OPEN','CLOSED') NOT NULL DEFAULT 'DRAFT',
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS candidate (
  candidate_id INT AUTO_INCREMENT PRIMARY KEY,
  election_id  INT NOT NULL,
  full_name    VARCHAR(200) NOT NULL,
  party        VARCHAR(120),
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cand (election_id, full_name),
  CONSTRAINT fk_cand_elec FOREIGN KEY (election_id)
    REFERENCES election(election_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ballot (
  ballot_id    INT AUTO_INCREMENT PRIMARY KEY,
  election_id  INT NOT NULL,
  voter_id     INT NOT NULL,
  candidate_id INT NOT NULL,
  cast_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_vote (election_id, voter_id),
  CONSTRAINT fk_ballot_elec FOREIGN KEY (election_id)
    REFERENCES election(election_id) ON DELETE CASCADE,
  CONSTRAINT fk_ballot_voter FOREIGN KEY (voter_id)
    REFERENCES voter(voter_id) ON DELETE RESTRICT,
  CONSTRAINT fk_ballot_cand FOREIGN KEY (candidate_id)
    REFERENCES candidate(candidate_id) ON DELETE RESTRICT
) ENGINE=InnoDB;
